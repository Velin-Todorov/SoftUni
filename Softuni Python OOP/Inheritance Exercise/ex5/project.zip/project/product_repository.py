from project.drink import Drink
from project.product import Product
from project.food import Food


class ProductRepository:
    def __init__(self):
        self.products = []

    def add(self, product: Product):
        self.products.append(product)
        return self.products

    def find(self, product_name: str):
        product = 0
        for p in self.products:
            if p.name == product_name:
                product = p
                break

        return product

    def remove(self, product_name):
        for p in self.products:
            if p == product_name:
                self.products.remove(p)

    def __repr__(self):
        result = ''
        for p in self.products:
            result += f'{p.name}: {p.quantity}\n'

        return result.strip()

