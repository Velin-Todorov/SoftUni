function getInfo() {
    let stopId = document.getElementById('stopId')
    let submit = document.getElementById('submit')

    let result = document.getElementById('result')
    let stopName = document.getElementById('stopName')
    let buses = document.getElementById('buses')


    submit.addEventListener('click', () => {

        httpRequest = new XMLHttpRequest();
        let url = `http://localhost:3030/jsonstore/bus/businfo/${stopId.value}`
        httpRequest.addEventListener('readystatechange', () => {

            if (httpRequest.readyState == 4 && httpRequest.status == 200) {
                let text = JSON.parse(httpRequest.responseText)
                stopName.textContent = text.name
                
                for (const key in text.buses){
                    let li = document.createElement('li')
                    li.textContent = `Bus ${key} arrives in ${text.buses[key]} minutes`
                    buses.appendChild(li);
                }



            }else{
                stopName.textContent = 'Error'
            }
        })

        httpRequest.open('GET', url)
        buses.innerHTML = ''
        httpRequest.send();
    })


}